﻿namespace MvvmLight1
{
    public sealed partial class TestUserControl
    {
        public TestUserControl()
        {
            InitializeComponent();
        }
    }
}